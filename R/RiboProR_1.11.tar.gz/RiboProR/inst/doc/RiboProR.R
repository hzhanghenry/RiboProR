### R code from vignette source 'RiboProR.Rnw'

###################################################
### code chunk number 1: RiboProR.Rnw:140-141 (eval = FALSE)
###################################################
## library(RiboProR);


###################################################
### code chunk number 2: RiboProR.Rnw:143-147 (eval = FALSE)
###################################################
## bed_file <- system.file("extdata", "yeast-all.bed", package="RiboProR");
## yeast_cds <- rtracklayer::import(bed_file, format="BED");
## defaultInsets <- getDefaultInset();  
## transcript_size <- regionCountFrame(countSizes(defaultInsets, yeast_cds));


###################################################
### code chunk number 3: RiboProR.Rnw:149-151 (eval = FALSE)
###################################################
## ribo_bam_file <- "give_your_own_bam_file_here";
## asite_table <- FpFraming(ribo_bam_file, bed_file);


###################################################
### code chunk number 4: RiboProR.Rnw:153-159 (eval = FALSE)
###################################################
## riboseq_asite <- data.frame(asite=asite_table[,2], 
## 				row.names=rownames(asite_table));
## ribo_fpCounts <- regionCountFrame(countAligns(riboseq_asite, defaultInsets,
## 	ribo_bam_file, yeast_cds));
## write.table(ribo_fpCounts, file="ribo_sample_1_fp_count.txt", sep="\t", 
## 	quote=FALSE, row.names=TRUE, col.names=TRUE);  


###################################################
### code chunk number 5: RiboProR.Rnw:161-167 (eval = FALSE)
###################################################
## rna_bam_file <- "RNASeq.bam";
## rnaseq_asite <- getDefaultRNASeqAsites();
## rna_counts <- regionCountFrame(countAligns(rnaseq_asite, defaultInsets,
## 	rna_bam_file, yeast_cds));
## write.table(rna_counts, file="rna_sample_1_count.txt", sep="\t", 
## 	quote=FALSE, row.names=TRUE, col.names=TRUE);


###################################################
### code chunk number 6: RiboProR.Rnw:179-184 (eval = FALSE)
###################################################
## directory_name <- "/data/user_name/project_name/raw_counts_From_R";
## file_name_pattern <- "_counts.txt";
## count_column <- 2;
## rowname_column <- 0;
## has.header <- TRUE;


###################################################
### code chunk number 7: RiboProR.Rnw:186-188 (eval = FALSE)
###################################################
## count_table <- getCountMatrixFromFiles(directory_name, file_name_pattern, 
## 	count_column, rowname_column, has.header);


###################################################
### code chunk number 8: RiboProR.Rnw:229-234 (eval = FALSE)
###################################################
## data(ribo_pro_data);
## mRNA_wildtype <- 4:6;
## mRNA_mutants  <- 10:12;
## Ribo_wildtype <- 1:3
## Ribo_mutants  <- 7:9;


###################################################
### code chunk number 9: RiboProR.Rnw:236-238 (eval = FALSE)
###################################################
## control_name <- "wildtype";
## mutant_name  <- "mutants";


###################################################
### code chunk number 10: RiboProR.Rnw:240-242 (eval = FALSE)
###################################################
## count_matrix <- getCountMatrixFromTable(ribo_pro_data, Ribo_wildtype, 
## 	Ribo_mutants, mRNA_wildtype, mRNA_mutants);


###################################################
### code chunk number 11: RiboProR.Rnw:248-250 (eval = FALSE)
###################################################
## mRNA_col <- 1:6; 
## ribo_col <- 7:12;


###################################################
### code chunk number 12: RiboProR.Rnw:252-254 (eval = FALSE)
###################################################
## mRNA_level <- 10;
## Ribo_level <- 0;


###################################################
### code chunk number 13: RiboProR.Rnw:256-258 (eval = FALSE)
###################################################
## count_matrix <- filterCountMatrix(count_matrix, mRNA_col, ribo_col,
## 	mRNA_level, Ribo_level);


###################################################
### code chunk number 14: RiboProR.Rnw:266-268 (eval = FALSE)
###################################################
## gene_list <- rownames(count_matrix);
## data(yeast_gene_description)


###################################################
### code chunk number 15: RiboProR.Rnw:270-276 (eval = FALSE)
###################################################
## has.header <- FALSE;
## id_column <- 1;
## name_column <- 2;
## desc_column <- 3; 
## gene_info <- getAnnotationInfo(yeast_gene_description, gene_list,  
## 	has.header, id_column, name_column, desc_column);


###################################################
### code chunk number 16: RiboProR.Rnw:288-292 (eval = FALSE)
###################################################
## num_Ribo_wildtype <- length(Ribo_wildtype);
## num_Ribo_mutant   <- length(Ribo_mutants);
## num_mRNA_wildtype <- length(mRNA_wildtype);
## num_mRNA_mutant   <- length(mRNA_mutants);


###################################################
### code chunk number 17: RiboProR.Rnw:294-296 (eval = FALSE)
###################################################
## dds <- getDESeqDataSet(count_matrix, num_Ribo_wildtype, num_Ribo_mutant,
## 	num_mRNA_wildtype, num_mRNA_mutant, gene_info);


###################################################
### code chunk number 18: RiboProR.Rnw:306-308 (eval = FALSE)
###################################################
## dds_TE <- runDESeq(dds, has.SizeFactors=FALSE, reset.design=FALSE);
## dds_TE <- extractEfficiencyChange(dds_TE, control_name, mutant_name);


###################################################
### code chunk number 19: RiboProR.Rnw:318-320 (eval = FALSE)
###################################################
## dds_RC <- runDESeq(dds, has.SizeFactors=FALSE, reset.design=TRUE);
## dds_RC <- extractTranscriptionChange(dds_RC, control_name, mutant_name);


###################################################
### code chunk number 20: RiboProR.Rnw:329-334 (eval = FALSE)
###################################################
## normalized_counts <- DESeq2::counts(dds_TE, normalize=TRUE);
## out_file <- paste0(mutant_name, "_vs_", control_name, 
## 	"_Normalized_counts.txt");
## write.table(normalized_counts, file=out_file, sep="\t", quote=FALSE,
## 	row.names=FALSE, col.names=TRUE)


###################################################
### code chunk number 21: RiboProR.Rnw:362-366 (eval = FALSE)
###################################################
## bam_file <- "RiboSeq.bam";
## bed_file <- system.file("extdata", "yeast-all.bed", package="RiboProR");
## asite_file <- system.file("extdata", "ribo_asite.txt", package="RiboProR"); 
## 


###################################################
### code chunk number 22: RiboProR.Rnw:368-373 (eval = FALSE)
###################################################
## yeast_bed <- rtracklayer::import(bed_file, "BED");
## asite <- readAsiteFromFile(asite_file);				
## wiggle_counts <- getWiggleCounts(bam_file, asite, bed_file);
## normed_counts <- normalizeWiggleCounts(wiggle_counts);
## writeWiggleFiles(normed_counts, bam_file, TRUE);


###################################################
### code chunk number 23: RiboProR.Rnw:394-397 (eval = FALSE)
###################################################
## frame_file <- system.file("extdata", "ribo_frame_len.txt", 
## 		package="RiboProR");
## fpFramePlot(frame_file);


###################################################
### code chunk number 24: RiboProR.Rnw:408-414 (eval = FALSE)
###################################################
## at_start <- system.file("extdata", "ribo_meta_start_frames.txt", 
## 	package="RiboProR");
## at_stop <- system.file("extdata", "ribo_meta_stop_frames.txt", 
## 	package="RiboProR");
## plotMetageneFrames(at_start, at_stop);
## title("Metagene Frame Distribution");


###################################################
### code chunk number 25: RiboProR.Rnw:425-429 (eval = FALSE)
###################################################
## count_file <- system.file("extdata", "ribo_meta_start_frames.txt", 
## 	package="RiboProR");
## plotMetageneCounts(count_file, from_position=-50, to_position=50, 
##     codon="Start", x_interval=10)


###################################################
### code chunk number 26: RiboProR.Rnw:458-459 (eval = FALSE)
###################################################
## fpCountsBoxPlot(dds_TE);


###################################################
### code chunk number 27: RiboProR.Rnw:470-471 (eval = FALSE)
###################################################
## plotReplicates(dds_TE);


###################################################
### code chunk number 28: RiboProR.Rnw:488-489 (eval = FALSE)
###################################################
## plotTranslationEfficiency(dds_TE)


###################################################
### code chunk number 29: RiboProR.Rnw:501-502 (eval = FALSE)
###################################################
## plotCorrelationHeatmap(dds_TE, image_name="ribo_sample");


###################################################
### code chunk number 30: RiboProR.Rnw:513-515 (eval = FALSE)
###################################################
## count_data <- getCountsData(dds_TE);
## plotCorrelationMatrix(count_data);


###################################################
### code chunk number 31: RiboProR.Rnw:534-548 (eval = FALSE)
###################################################
## control_TE <- DESeq2::results(dds_TE, contrast=c("condition","Ribo","mRNA"))
## mutant_TE <- DESeq2::results(dds_TE, list(c(DESeq2::resultsNames(dds_TE)[3], 
## 									DESeq2::resultsNames(dds_TE)[4])))
## 									
## mut_te <- as.numeric(mutant_TE[,2])
## wt_te  <- as.numeric(control_TE[,2])
## TE_fc  <- mut_te - wt_te
## sig_fc <- which(abs(TE_fc) >= 2)
## 
## plot_data <- DESeq2::counts(dds_TE, normalize=TRUE)
## plot_data <- plot_data[sig_fc,]
## 
## plotHeatmap(plot_data, sample_name="TE_data", gene_name=rownames(plot_data), 
## 		image_type="pdf", image_width=8, is.log2=FALSE, scale_by="row");


###################################################
### code chunk number 32: sessionInfo
###################################################
sessionInfo()


